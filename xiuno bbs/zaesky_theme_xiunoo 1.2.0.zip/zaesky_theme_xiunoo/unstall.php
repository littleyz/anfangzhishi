<?php

/*
	Xiuno BBS 4.0 xiuno O
*/

!defined('DEBUG') AND exit('Forbidden');


?>